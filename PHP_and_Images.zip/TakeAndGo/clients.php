<?php
function addToSqlQuery($Value,$Key){
	global $hasWhereStatment;
	global $sql;
	if(isset($Value) == true){
		if( $hasWhereStatment == true)
			 $sql .=" AND " . $Key . "='$Value'";	
		else{	
			 $sql .=" WHERE " . $Key . "='$Value'";
			 $hasWhereStatment =true;
		}
	}
}

try {
	require 'DB_Manage.php';

	$sql = "SELECT * FROM `clients_table`";
	$hasWhereStatment=false;
	$id = $_REQUEST["_id"];
    $lastName = $_REQUEST["lastName"];
    $firstName   = $_REQUEST["firstName"];
    $emailAdrs   = $_REQUEST["emailAdrs"];
    $phoneNum = $_REQUEST["phoneNum"];
	
	addToSqlQuery($id,"_id");
	addToSqlQuery($lastName,"lastName");
	addToSqlQuery($firstName,"firstName");
	addToSqlQuery($emailAdrs,"emailAdrs");
	addToSqlQuery($phoneNum,"phoneNum");
	
	$result = $conn->query($sql);
	$data = array();
	

		// output data of each row

		while ($row = $result->fetch_assoc()) {
			array_push($data, $row);
		}

		echo json_encode(array('clients' => $data));
	
}
catch(Exception $e) {
	echo "Error exception See Log....";
	error_log($e->getMessage() , 0);
}

$conn->close();
?>
