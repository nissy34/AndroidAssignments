<?php

try {
    
    require 'DB_Manage.php';
    
    
    $id = $_REQUEST["_id"];
   
	
	$sql="DELETE FROM `clients_table` WHERE _id='$id'";
   
	
	
	
    if ($conn->query($sql) === TRUE) {
        echo "Record ".$id." deleted successfully";
    } else {
        echo "Error: " . $sql . "\n" . $conn->error;
    }
    
}
catch (Exception $e) {	
	echo "Exception Error See Log....";
    error_log($e->getMessage(), 0);
}
$conn->close();
?>