<?php
function addToSqlQuery($Value,$Key){
	global $hasWhereStatment;
	global $sql;
	if(isset($Value) == true){
		if( $hasWhereStatment == true)
			 $sql .=" AND " . $Key . "='$Value'";	
		else{	
			 $sql .=" WHERE " . $Key . "='$Value'";
			 $hasWhereStatment =true;
		}
	}
}

try {
	require 'DB_Manage.php';
	
	//$date= date("y-m-d h:i:s");
	//TIMESTAMPDIFF(SECOND,`returnDate`,'$date')<=10
	$sql = "SELECT * 
	         FROM `cars_table` AS CT  
			 WHERE    CT._id NOT IN (SELECT `carNumber`
			                          FROM `orders_table`
									  WHERE `order_Status`=0)";
	
	        
	$id = $_REQUEST["_id"];
	$branchNum = $_REQUEST["branchNum"];
    $carModelID   = $_REQUEST["carModelID"];
    $kilometers   = $_REQUEST["kilometers"];
    $interval = $_REQUEST["interval"];
	
	
	
	addToSqlQuery($id,"_id");
	addToSqlQuery($branchNum,"branchNum");
	addToSqlQuery($carModelID,"carModelID");
	
		
	$result = $conn->query($sql);
	$data = array();
	
		// output data of each row

		while ($row = $result->fetch_assoc()) {
			array_push($data, $row);
		}

		echo json_encode(array('cars' => $data));
	
	
}
catch(Exception $e) {
	echo "Error exception  See Log....";
	error_log($e->getMessage() , 0);
}

$conn->close();
?>
