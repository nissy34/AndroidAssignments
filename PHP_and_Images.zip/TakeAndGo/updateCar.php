<?php

try {
    
    require 'DB_Manage.php';
    
    
    $id = $_REQUEST["_id"];
    $kilometers= $_REQUEST["kilometers"];
    $carModelID   = $_REQUEST["carModelID"];
    $branchNum   = $_REQUEST["branchNum"];
    
	
   
	$sql="UPDATE `cars_table` SET `kilometers`='$kilometers',`carModelID`='$carModelID',`branchNum`='$branchNum' WHERE _id='$id'";
	
	
	
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error: " . $sql . "\n" . $conn->error;
    }
    
}
catch (Exception $e) {	
	echo "Exception Error See Log....";
    error_log($e->getMessage(), 0);
}
$conn->close();
?>