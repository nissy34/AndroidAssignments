<?php

try {
    
    require 'DB_Manage.php';
    
	$PATH_IMAGE='images/carModel/';

    
    $id = $_REQUEST["_id"];
    $compenyName       = $_REQUEST["compenyName"];
    $modelName   = $_REQUEST["modelName"];
    $engineCapacity   = $_REQUEST["engineCapacity"];
    $transmissionType = $_REQUEST["transmissionType"];
	$numOfSeats = $_REQUEST["numOfSeats"];
	$carPic = $_REQUEST["carPic"];
	$carClass = $_REQUEST["carClass"];
	
	$sqlImage="SELECT `carPic` FROM  `carmodels_table` WHERE `_id`='$id'";
    
	
	
if ($result=mysqli_query($conn,$sqlImage))
  {
  // Fetch one and one row
  if ($row=mysqli_fetch_row($result))
    {
	  $link_array = explode('/',$row[0]);
     $page = end($link_array);
    unlink("images/carModel/".$page);
    }
  // Free result set
  mysqli_free_result($result);
}
	 
           
    
	
	$PATH_IMAGE_NAME=$PATH_IMAGE.'carModel_id_'.uniqid().'.png';
	
	$carPicURL='http://nheifetz.vlab.jct.ac.il/TakeAndGo/'.$PATH_IMAGE_NAME;

	$sql="UPDATE `carmodels_table` SET `compenyName`='$compenyName',`modelName`='$modelName',`engineCapacity`='$engineCapacity',`transmissionType`='$transmissionType',`carPic`='$carPicURL',`carClass`='$carClass',`numOfSeats`='$numOfSeats' WHERE _id='$id'";
	
	
		function uploadTimelineImage($base64Img,$h,$w,$fileName)
{
	
    $im = imagecreatefromstring($base64Img);
		
    if ($im !== false) {


        $width = imagesx($im);
        $height = imagesy($im);
        $r = $width / $height; // ratio of image

        // calculating new size for maintain ratio of image
        if ($w/$h > $r) {
            $newwidth = $h*$r; 
            $newheight = $h;
        } else {
            $newheight = $w/$r;
            $newwidth = $w;
        }

        $dst = imagecreatetruecolor($newwidth, $newheight);
		imagealphablending( $dst, false );
           imagesavealpha( $dst, true );
        imagecopyresampled($dst, $im, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
        imagedestroy($im);

        
       // $filepath =  "{$PATH_IMAGE}carModel_id_{$fileName}.png"  ;
		
		
        imagepng($dst,$fileName);

        imagedestroy($dst);
        return $fileName;
    }
    else
    {
        return "";
    }
}
    uploadTimelineImage(base64_decode($carPic),500,500,$PATH_IMAGE_NAME);
   
    if ($conn->query($sql) === TRUE) {
        echo $id;
    } else {
        echo "Error: " . $sql . "\n" . $conn->error;
    }
    
}
catch (Exception $e) {	
	echo "Exception Error See Log....";
    error_log($e->getMessage(), 0);
}
$conn->close();
?>