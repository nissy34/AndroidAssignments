<?php

try {
    
    require 'DB_Manage.php';

 
    $id = $_REQUEST["_id"];
	$carNumber = $_REQUEST["carNumber"];
    $order_Status = $_REQUEST["order_Status"];
	$returnDate = $_REQUEST["returnDate"];
	$kilometersAtReturn = $_REQUEST["kilometersAtReturn"];
	$fouled = $_REQUEST["fouled"];
	$amountOfFoul = $_REQUEST["amountOfFoul"];
	$finalAmount = $_REQUEST["finalAmount"];

if($fouled==1)	{
	$sql= "UPDATE
    	`orders_table`
	SET
    	`order_Status` =  '$order_Status' ,
    	`returnDate` = '$returnDate',
    	`kilometersAtReturn` = '$kilometersAtReturn',
    	`fouled` = '$fouled',
    	`amountOfFoul` = '$amountOfFoul',
    	`finalAmount` = '$finalAmount'
	WHERE
    	`_id`='$id'";
}
else
{
		$sql= "UPDATE
    	`orders_table`
	SET
    	`order_Status` =  '$order_Status' ,
   	    `returnDate` = '$returnDate',
    	`kilometersAtReturn` = '$kilometersAtReturn',
    	`fouled` = '$fouled',
    	`finalAmount` = '$finalAmount'
	WHERE
    	`_id`='$id'";
}
	
    if ($conn->query($sql) == TRUE) {
	
		//echo $id;
     
		$sqlCar="UPDATE
    	`cars_table`
	SET
    
    	`kilometers` = '$kilometersAtReturn'
    	
	WHERE
    	`_id`='$carNumber'";
		if ($conn->query($sqlCar) == TRUE) {
			echo $id;
		}
		 else {
        echo "Error: " . $sqlCar . "\n" . $conn->error;
    }
			
    } else {
        echo "Error: " . $sql . "\n" . $conn->error;
    }
    
}
catch (Exception $e) {	
	echo "Error Exception See Log....";
    error_log($e->getMessage(), 0);
}
$conn->close();
?>