<?php

try {
    
    require 'DB_Manage.php';
    $id = $_REQUEST["_id"];
    $branchNum = $_REQUEST["branchNum"];
    $carModelID   = $_REQUEST["carModelID"];
    $kilometers   = $_REQUEST["kilometers"];

    $sql= "INSERT INTO `cars_table`(`_id`, `kilometers`, `carModelID`, `branchNum`) 
							VALUES ('$id','$kilometers', '$carModelID', '$branchNum')";
	
    if ($conn->query($sql) === TRUE) {
        echo $id;
    } else {
        echo "Error: " . $sql . "\n" . $conn->error;
    }
    
}
catch (Exception $e) {	
	echo "Error Exception See Log....";
    error_log($e->getMessage(), 0);
}
$conn->close();
?>