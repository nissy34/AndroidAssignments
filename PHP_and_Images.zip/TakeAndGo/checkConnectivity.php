<?php

echo 1;
?>