<?php

try {
    
    require 'DB_Manage.php';
    
   
        
    $id = $_REQUEST["_id"];
    $lastName = $_REQUEST["lastName"];
    $firstName   = $_REQUEST["firstName"];
    $emailAdrs   = $_REQUEST["emailAdrs"];
    $phoneNum = $_REQUEST["phoneNum"];
	$salt = $_REQUEST["salt"];
	$password = $_REQUEST["password"];
    $craditCard = $_REQUEST["craditCard"];
	
		$sql=	"UPDATE
                         `clients_table`
                                          SET 
                                               `lastName`= '$lastName',
                                               `firstName`= '$firstName',
                                               `emailAdrs`='$emailAdrs',
                                               `phoneNum`= '$phoneNum',
                                                `salt`= '$salt',
                                              `password`='$password',
											  `craditcard`='$craditCard'
                                          WHERE
                                               `_id`='$id'
             ";
	
	
	
	
	
       
     

    
    if ($conn->query($sql) === TRUE) {
        echo $id;
    } else {
        echo "Error: " . $sql . "\n" . $conn->error;
    }
    
}
catch (Exception $e) {	
	echo "Exception Error See Log....";
    error_log($e->getMessage(), 0);
}
$conn->close();
?>