<?php

try {
    
    require 'DB_Manage.php';
    
   
        
    $id = $_REQUEST["_id"];
    $lastName = $_REQUEST["lastName"];
    $firstName   = $_REQUEST["firstName"];
    $emailAdrs   = $_REQUEST["emailAdrs"];
    $phoneNum = $_REQUEST["phoneNum"];
	$salt = $_REQUEST["salt"];
	$password = $_REQUEST["password"];
	$craditCard = $_REQUEST["craditCard"];
	
	
	 $sql=	"INSERT
                     INTO
                         `clients_table`(
                             `_id`,
                             `lastName`,
                             `firstName`,
                             `emailAdrs`,
                             `phoneNum`,
                             `salt`,
                             `password`,
							 `craditCard`
                         )
                     VALUES(
					         '$id',
                             '$lastName' ,
                             '$firstName',
                             '$emailAdrs',
                             '$phoneNum' ,
                             
                             '$salt',
                             '$password', 
							 '$craditCard'
                     )";
	
	
	
	
	
       
     
    
    if ($conn->query($sql) == TRUE) {
        echo $id;
    } else {
        echo "Error: " . $sql . "\n" . $conn->error;
    }
    
}
catch (Exception $e) {	
	echo "Error Exception  See Log....";
    error_log($e->getMessage(), 0);
}
$conn->close();
?>