<?php

try {
    
    require 'DB_Manage.php';
    $PATH_IMAGE='images/carModel/';
    
    $id = $_REQUEST["_id"];
    $compenyName = $_REQUEST["compenyName"];
    $modelName   = $_REQUEST["modelName"];
    $engineCapacity   = $_REQUEST["engineCapacity"];
    $transmissionType = $_REQUEST["transmissionType"];
	$numOfSeats = $_REQUEST["numOfSeats"];
	$carPic = $_REQUEST["carPic"];
	$carClass = $_REQUEST["carClass"];
	
	$PATH_IMAGE_NAME=$PATH_IMAGE.'carModel_id_'.$id.'.png';
	
	$carPicURL='http://nheifetz.vlab.jct.ac.il/TakeAndGo/'.$PATH_IMAGE_NAME;

    $sql= "INSERT INTO `carmodels_table`(`_id`, `compenyName`, `modelName`, `engineCapacity`, `transmissionType`, `carPic`, `carClass`, `numOfSeats`) VALUES ('$id', '$compenyName', '$modelName', '$engineCapacity', '$transmissionType', '$carPicURL', '$carClass', '$numOfSeats')";


	
	function uploadTimelineImage($base64Img,$h,$w,$fileName)
{
	
    $im = imagecreatefromstring($base64Img);
		
    if ($im !== false) {


        $width = imagesx($im);
        $height = imagesy($im);
        $r = $width / $height; // ratio of image

        // calculating new size for maintain ratio of image
        if ($w/$h > $r) {
            $newwidth = $h*$r; 
            $newheight = $h;
        } else {
            $newheight = $w/$r;
            $newwidth = $w;
        }

        $dst = imagecreatetruecolor($newwidth, $newheight);
		imagealphablending( $dst, false );
           imagesavealpha( $dst, true );
        imagecopyresampled($dst, $im, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
        imagedestroy($im);

        
       // $filepath =  "{$PATH_IMAGE}carModel_id_{$fileName}.png"  ;
		
		
        imagepng($dst,$fileName);

        imagedestroy($dst);
        return $fileName;
    }
    else
    {
        return "";
    }
}
    $f=	uploadTimelineImage(base64_decode($carPic),500,500,$PATH_IMAGE_NAME);
	
    if ($conn->query($sql) === TRUE) {
     echo $id;
    } else {
        echo "Error: " . $sql . "\n" . $conn->error;
    }
    
}
catch (Exception $e) {	
	echo "Error Exception See Log....";
    error_log($e->getMessage(), 0);
}
$conn->close();
?>