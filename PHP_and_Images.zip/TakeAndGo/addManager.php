<?php

try {
    
    require 'DB_Manage.php';
    
   
        
    $id = $_REQUEST["_id"];
    $lastName = $_REQUEST["lastName"];
    $firstName   = $_REQUEST["firstName"];
    $emailAdrs   = $_REQUEST["emailAdrs"];
    $phoneNum = $_REQUEST["phoneNum"];
	$salt = $_REQUEST["salt"];
	$password = $_REQUEST["password"];
	
	if(isset($_REQUEST["branchId"])){
		$branchId=$_REQUEST["branchId"];
		$sql=	"INSERT
                     INTO
                         `managers_table`(
                             `_id`,
                             `lastName`,
                             `firstName`,
                             `emailAdrs`,
                             `phoneNum`,
                             `branchId`,
                             `salt`,
                             `password`
                         )
                     VALUES(
					         '$id',
                             '$lastName' ,
                             '$firstName',
                             '$emailAdrs',
                             '$phoneNum' ,
                              '$branchId' ,
                             '$salt',
                             '$password' 
                     )";
     
	}
	else {
	 $sql=	"INSERT
                     INTO
                         `managers_table`(
                             `_id`,
                             `lastName`,
                             `firstName`,
                             `emailAdrs`,
                             `phoneNum`,
                           
                             `salt`,
                             `password`
                         )
                     VALUES(
					         '$id',
                             '$lastName' ,
                             '$firstName',
                             '$emailAdrs',
                             '$phoneNum' ,
                             
                             '$salt',
                             '$password' 
                     )";
	}
	
	
	
	
       
     
    
    if ($conn->query($sql) === TRUE) {
        echo $id;
    } else {
        echo "Error: " . $sql . "\n" . $conn->error;
    }
    
}
catch (Exception $e) {	
	echo "Error Exception  See Log....";
    error_log($e->getMessage(), 0);
}
$conn->close();
?>