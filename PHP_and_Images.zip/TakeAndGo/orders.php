<?php
	
function addToSqlQuery($Value,$Key){
	global $hasWhereStatment;
	global $sql;
	if(isset($Value) == true){
		if( $hasWhereStatment == true)
			 $sql .=" AND " . $Key . "='$Value'";	
		else{	
			 $sql .=" WHERE " . $Key . "='$Value'";
			 $hasWhereStatment =true;
		}
	}
}

try {
	require 'DB_Manage.php';	
	
	 $hasWhereStatment =false;
			
	
	$sql="SELECT * FROM `orders_table`";
	
	$id = $_REQUEST["_id"];
    $orderStatus = $_REQUEST["order_Status"];
    $ClientId   = $_REQUEST["Client_Id"];
    $carNumber = $_REQUEST["carNumber"];
    $rentDate = $_REQUEST["rentDate"];
	$returnDate = $_REQUEST["returnDate"];
	$kilometersAtRent = $_REQUEST["kilometersAtRent"];
	$kilometersAtReturn = $_REQUEST["kilometersAtReturn"];
	$fouled = $_REQUEST["fouled"];
	$amountOfFoul = $_REQUEST["amountOfFoul"];
	$finalAmount = $_REQUEST["finalAmount"];
	
	addToSqlQuery($id,"_id");
	addToSqlQuery($orderStatus,"order_Status");
	addToSqlQuery($ClientId,"Client_Id");
	addToSqlQuery($carNumber,"carNumber");
	addToSqlQuery($rentDate,"rentDate");
	addToSqlQuery($returnDate,"returnDate");
	addToSqlQuery($kilometersAtRent,"kilometersAtRent");	
	addToSqlQuery($kilometersAtReturn,"kilometersAtReturn");
	addToSqlQuery($fouled,"fouled");	
	addToSqlQuery($amountOfFoul,"amountOfFoul");	
	addToSqlQuery($finalAmount,"finalAmount");	
	

	$result = $conn->query($sql);
	$data = array();
	

		// output data of each row

		while ($row = $result->fetch_assoc()) {
			array_push($data, $row);
		}

		echo json_encode(array('orders' => $data));
	
}
catch(Exception $e) {
	echo "Error exception See Log....";
	error_log($e->getMessage() , 0);
}

$conn->close();
?>


