<?php
try {
	require 'DB_Manage.php';
	$sql = "SELECT * FROM `branches_table`";
	$city = $_REQUEST["city"];
	if(isset($city) == true)
		 $sql .=" WHERE city ='$city'";
	$result = $conn->query($sql);
	$data = array();
	

		// output data of each row

		while ($row = $result->fetch_assoc()) {
			array_push($data, $row);
		}

		echo json_encode(array('branches' => $data));
	

}
catch(Exception $e) {
	echo "Error Exception  See Log....";
	error_log($e->getMessage() , 0);
}

$conn->close();
?>
