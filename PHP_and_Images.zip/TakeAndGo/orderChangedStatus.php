<?php

try {
    
    require 'DB_Manage.php';
	date_default_timezone_set('Israel');
     $interval   = $_REQUEST["interval"];
	 $interval= $interval+5;
	//echo $interval."\n";
    $date= date("Y-m-d H:i:s");

    $sql= "SELECT * FROM `orders_table` where (`returnDate` IS NOT NULL) AND  (ABS(TIMESTAMPDIFF(SECOND,`returnDate`,'$date'))<='$interval')";
	
	$result=$conn->query($sql);
	
    if ($result == TRUE) {
	     
       echo $result->num_rows."\n";
		
    } else {
        echo "Error: " . $sql . "\n" . $conn->error;
    }
    
	/*
	$result = $conn->query($sql);
	$data = array();
	
		// output data of each row

		while ($row = $result->fetch_assoc()) {
			array_push($data, $row);
		}

		echo json_encode(array('cars' => $data));
		*/
}
catch (Exception $e) {	
	echo "Error Exception See Log....";
    error_log($e->getMessage(), 0);
}
$conn->close();
?>