<?php
function addToSqlQuery($Value,$Key){
	global $hasWhereStatment;
	global $sql;
	if(isset($Value) == true){
		if( $hasWhereStatment == true)
			 $sql .=" AND " . $Key . "='$Value'";	
		else{	
			 $sql .=" WHERE " . $Key . "='$Value'";
			 $hasWhereStatment =true;
		}
	}
}
try {
	require 'DB_Manage.php';

	$sql = "SELECT * FROM `carmodels_table`";
	
	$hasWhereStatment =false;
	$id = $_REQUEST["_id"];
    $compenyName = $_REQUEST["compenyName"];
    $modelName   = $_REQUEST["modelName"];
    $engineCapacity   = $_REQUEST["engineCapacity"];
    $transmissionType = $_REQUEST["transmissionType"];
	$numOfSeats = $_REQUEST["numOfSeats"];
	$carClass = $_REQUEST["carClass"];
	addToSqlQuery($id,"_id");
	addToSqlQuery($compenyName,"compenyName");
	addToSqlQuery($modelName,"modelName");
	addToSqlQuery($engineCapacity,"engineCapacity");
	addToSqlQuery($transmissionType,"transmissionType");
	addToSqlQuery($numOfSeats,"numOfSeats");
	addToSqlQuery($carClass,"carClass");
	
	$result = $conn->query($sql);
	$data = array();
	

		// output data of each row

		while ($row = $result->fetch_assoc()) {
			array_push($data, $row);
		}

		echo json_encode(array('car_models' => $data));
	
	
}
catch(Exception $e) {
	echo "Error exception See Log....";
	error_log($e->getMessage() , 0);
}

$conn->close();
?>
