<?php


header('Content-Type: text/html; charset=utf-8');
$servername = "localhost";
$username = "yn";
$password = "takedb";
$dbname = "yn_rentalDB";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

//mysql_query("SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', character_set_database = 'utf8', character_set_server = 'utf8'", $conn);
mysql_query($conn,"SET NAMES 'utf8'");
//mysql_set_charset('utf8');

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
?>