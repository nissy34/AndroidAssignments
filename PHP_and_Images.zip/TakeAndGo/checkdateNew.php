<?php

try {
    
    require 'DB_Manage.php';
	date_default_timezone_set('Israel');
	
     $date= date("y-m-d h:i:s");
     echo $date."\n";
    $sql= "SELECT ABS(TIMESTAMPDIFF(SECOND,`returnDate`,'$date')) FROM `orders_table`";
	$result=$conn->query($sql);
	
    if ($result == TRUE) {
     echo($result->fetch_row()[0]);
    } else {
        echo "Error: " . $sql . "\n" . $conn->error;
    }
    
	
}
catch (Exception $e) {	
	echo "Error Exception See Log....";
    error_log($e->getMessage(), 0);
}
$conn->close();
?>