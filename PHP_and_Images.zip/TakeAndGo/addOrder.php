<?php

try {
    
    require 'DB_Manage.php';
    $PATH_IMAGE='images/carModel/';
  /*  
    $id = $_REQUEST["_id"];
    $order_Status = $_REQUEST["order_Status"];
    $Client_Id   = $_REQUEST["Client_Id"];
    $carNumber   = $_REQUEST["carNumber"];
    $rentDate = $_REQUEST["rentDate"];
	$returnDate = $_REQUEST["returnDate"];
	$kilometersAtRent = $_REQUEST["kilometersAtRent"];
	$kilometersAtReturn = $_REQUEST["kilometersAtReturn"];
	$fouled = $_REQUEST["fouled"];
	$amountOfFoul = $_REQUEST["amountOfFoul"];
	$finalAmount = $_REQUEST["finalAmount"];

	


    $sql= 	"INSERT
INTO
    `orders_table`(
        `_id`,
        `order_Status`,
        `Client_Id`,
        `carNumber`,
        `rentDate`,
        `returnDate`,
        `kilometersAtRent`,
        `kilometersAtReturn`,
        `fouled`,
        `amountOfFoul`,
        `finalAmount`
    )
VALUES(
        '$id',
        '$order_Status',
        '$Client_Id',
        '$carNumber',
        '$rentDate',
        '$returnDate',
        '$kilometersAtRent',
        '$kilometersAtReturn',
        '$fouled',
        '$amountOfFoul',
        '$finalAmount'
)";

*/
	
    if (isset($_REQUEST["_id"]))
        $id = $_REQUEST["_id"];
    else
        $id = 'NULL';
	$order_Status = $_REQUEST["order_Status"];
    $Client_Id   = $_REQUEST["Client_Id"];
    $carNumber   = $_REQUEST["carNumber"];
    $rentDate = $_REQUEST["rentDate"];
	$kilometersAtRent = $_REQUEST["kilometersAtRent"];

	

	


    $sql= 	"INSERT
INTO
    `orders_table`(
        `_id`,
        `order_Status`,
        `Client_Id`,
        `carNumber`,
        `rentDate`,
        `kilometersAtRent`
    )
VALUES(
        '$id',
        '$order_Status',
        '$Client_Id',
        '$carNumber',
        '$rentDate',
		'$kilometersAtRent'
)";
	
    if ($conn->query($sql) == TRUE) {
      $last_id = $conn->insert_id;
        echo $last_id;

    } else {
        echo "Error: " . $sql . "\n" . $conn->error;
    }
    
}
catch (Exception $e) {	
	echo "Error Exception See Log....";
    error_log($e->getMessage(), 0);
}
$conn->close();
?>