<?php

try {
    
    require 'DB_Manage.php';
    
    
    $id = $_REQUEST["_id"];
   
	
	
	
	$sqlImage="SELECT `carPic` FROM  `carmodels_table` WHERE `_id`='$id'";
    
	
	
if ($result=mysqli_query($conn,$sqlImage))
  {
  // Fetch one and one row
  if ($row=mysqli_fetch_row($result))
    {
	  $link_array = explode('/',$row[0]);
     $page = end($link_array);
    unlink("images/carModel/".$page);
    }
  // Free result set
  mysqli_free_result($result);
}
	 
	
	
	
	$sql="DELETE FROM `carmodels_table` WHERE _id='$id'";
   
	
	
	
    if ($conn->query($sql) === TRUE) {
        echo "Record ".$id." deleted successfully";
    } else {
        echo "Error: " . $sql . "\n" . $conn->error;
    }
    
}
catch (Exception $e) {	
	echo "Exception Error See Log....";
    error_log($e->getMessage(), 0);
}
$conn->close();
?>