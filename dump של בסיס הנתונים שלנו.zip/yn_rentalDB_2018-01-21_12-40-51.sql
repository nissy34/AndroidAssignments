-- MySQL dump 10.14  Distrib 5.5.52-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: yn_rentalDB
-- ------------------------------------------------------
-- Server version	5.5.52-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `yn_rentalDB`
--


--
-- Table structure for table `branches_table`
--

DROP TABLE IF EXISTS `branches_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branches_table` (
  `_id` int(11) NOT NULL,
  `number_of_parking_spaces` int(11) NOT NULL,
  `city` enum('Akko','Afula','Arad','Ariel','Ashdod','Ashkelon','Baqa-Jatt','Bat Yam','Beersheba','Beit She''an','Beit Shemesh','Beitar Illit','Bnei Brak','Dimona','Eilat','El''ad','Giv''atayim','Giv''at Shmuel','Hadera','Haifa','Herzliya','Hod HaSharon','Holon','Jerusalem','Karmiel','Kfar Saba','Kiryat Ata','Kiryat Bialik','Kiryat Gat','Kiryat Malakhi','Kiryat Motzkin','Kiryat Ono','Kiryat Shmona','Kiryat Yam','Lod','Ma''ale Adumim','Ma''alot-Tarshiha','Migdal HaEmek','Modi''in Illit','Modi''in-Maccabim-Re''ut','Nahariya','Nazareth','Nazareth Illit','Nesher','Ness Ziona','Netanya','Netivot','Ofakim','Or Akiva','Or Yehuda','Petah Tikva','Qalansawe','Ra''anana','Rahat','Ramat Gan','Ramat HaSharon','Ramla','Rehovot','Rishon LeZion','Rosh HaAyin','Safed','Sderot','Shfar''am','Tamra','Tel Aviv','Tiberias','Tira','Tirat Carmel','Yavne','Yehud-Monosson','Yokneam') NOT NULL,
  `street` varchar(20) NOT NULL,
  `number` int(11) NOT NULL,
  `branchImgUrl` varchar(100) NOT NULL,
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches_table`
--

LOCK TABLES `branches_table` WRITE;
/*!40000 ALTER TABLE `branches_table` DISABLE KEYS */;
INSERT INTO `branches_table` VALUES (1,2,'Jerusalem','agasi',5,'http://nheifetz.vlab.jct.ac.il/TakeAndGo/images/branches/hadera.jpg'),(2,65,'Netanya','hertzal',55,'http://nheifetz.vlab.jct.ac.il/TakeAndGo/images/branches/netanya.jpg');
/*!40000 ALTER TABLE `branches_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carmodels_table`
--

DROP TABLE IF EXISTS `carmodels_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carmodels_table` (
  `_id` int(11) NOT NULL,
  `compenyName` varchar(25) NOT NULL,
  `modelName` varchar(25) NOT NULL,
  `engineCapacity` int(11) NOT NULL,
  `transmissionType` enum('MANUAL','AUTOMATIC') NOT NULL DEFAULT 'MANUAL',
  `carPic` varchar(100) NOT NULL,
  `carClass` enum('A','B','C','D','E','F','G','H','I','J') NOT NULL DEFAULT 'A',
  `numOfSeats` tinyint(4) NOT NULL,
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carmodels_table`
--

LOCK TABLES `carmodels_table` WRITE;
/*!40000 ALTER TABLE `carmodels_table` DISABLE KEYS */;
INSERT INTO `carmodels_table` VALUES (2,'BMW','m2',2000,'AUTOMATIC','http://nheifetz.vlab.jct.ac.il/TakeAndGo/images/carModel/carModel_id_5a5cdd11ea9f1.png','E',6),(5,'mazda','cx 5',2000,'AUTOMATIC','http://nheifetz.vlab.jct.ac.il/TakeAndGo/images/carModel/carModel_id_5a5cdca88447b.png','F',6),(30,'Hyundai','i30',1599,'AUTOMATIC','http://nheifetz.vlab.jct.ac.il/TakeAndGo/images/carModel/carModel_id_5a2e71d53adb5.png','E',5),(69885,'audi','Q5',2000,'MANUAL','http://nheifetz.vlab.jct.ac.il/TakeAndGo/images/carModel/carModel_id_69885.png','C',5);
/*!40000 ALTER TABLE `carmodels_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cars_table`
--

DROP TABLE IF EXISTS `cars_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cars_table` (
  `_id` int(11) NOT NULL,
  `kilometers` int(11) NOT NULL,
  `carModelID` int(11) NOT NULL,
  `branchNum` int(11) NOT NULL,
  PRIMARY KEY (`_id`),
  KEY `carModelID` (`carModelID`),
  KEY `branchNum` (`branchNum`),
  CONSTRAINT `cars_table_ibfk_2` FOREIGN KEY (`branchNum`) REFERENCES `branches_table` (`_id`),
  CONSTRAINT `cars_table_ibfk_1` FOREIGN KEY (`carModelID`) REFERENCES `carmodels_table` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars_table`
--

LOCK TABLES `cars_table` WRITE;
/*!40000 ALTER TABLE `cars_table` DISABLE KEYS */;
INSERT INTO `cars_table` VALUES (0,564649,2,1),(1,6000,69885,2),(80,64912,30,1),(123,2290,2,2),(458,2200,2,1),(558,888,2,1),(566,5700,2,1),(569,4543522,30,2),(586,600,5,2),(856,465656,2,1),(999,957,2,1),(3688,8988,2,1),(5584,855,2,1),(5695,5555,2,1),(25868,579,2,1),(87679,796,2,1),(764646,76798,2,1),(2223388,380,2,2),(2426662,1223545,5,1);
/*!40000 ALTER TABLE `cars_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients_table`
--

DROP TABLE IF EXISTS `clients_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients_table` (
  `_id` bigint(30) NOT NULL,
  `emailAdrs` varchar(30) NOT NULL,
  `phoneNum` varchar(10) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `password` varchar(64) NOT NULL,
  `salt` bigint(40) NOT NULL,
  `craditCard` bigint(40) NOT NULL,
  PRIMARY KEY (`_id`),
  UNIQUE KEY `emailAdrs` (`emailAdrs`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients_table`
--

LOCK TABLES `clients_table` WRITE;
/*!40000 ALTER TABLE `clients_table` DISABLE KEYS */;
INSERT INTO `clients_table` VALUES (1,'nissy34@gmail.com','0527158843','yuval','nager','f931c308fc5b60b421c09969912839dff2776957d98b8d2f91c554ed8fc80f78',4321,1234),(3,'nissy@gmail.com','0527158843','yuval','nager','f931c308fc5b60b421c09969912839dff2776957d98b8d2f91c554ed8fc80f78',4321,1234),(123,'ni@gmail.com','05871','a','asdf','43f6e3b1a2073d9df8aca6168c52bdf7c60d5a6330adff42f74738dda1550159',-5134694576181641968,123456789),(1234,'dd@gmail.com','0587158843','david','dagan','b67357ae1d61d6f2c67e971f5730b312d7b9a25ccd7ef4c6b5385e875397d3f2',-8060959300843177173,43242),(4646,'na@gmail.com','87940','hssh','sjsj','f74623c8762062947a76e9020760af2a4fb50f43a878f4042c74c89370232f75',-6976974068605324685,123467587787676),(5588,'nissya@gmail.com','0888586','fgh','ffg','fd24e280c34298de5453f41bb6d53b8cee1d195ccd272cbb3f26015de31660c6',-227496577816852359,3424),(25896,'nissy334@gmail.com','0527158843','nissy','heifetz','71ebfbc154dc63fce3c0a7ec7c157e1657e095a82138aab479e2b794aa96bba1',7945824204981587556,123456789),(580580,'e@gmail.com','0505','y','n','d29c22708a40323fd4cd1ed402ff2af4f148fc93a056afc113ff3f267e357be2',-3716202176295486784,558855),(12345687,'a@gmail.com','0525788','× ×™×¡×Ÿ','×—×¤×¥','390600b967ec83a2775dcd28af406a90bae7839c6814e8bcdbaec41b9d0cb91d',7944395768213795704,123456796),(289899844,'nis@gmail.com','0587566855','ghjh','fghh','8558bc3c26432afd58546138389e524d269d05cbc9a4eb6f6beee85a1a9ea5b3',5682159011953060983,254555885),(308142488,'benda1237@gmail.com','0506456233','ziv','ben david','8d1312499f80ffad2c2e30db01936df4c700b1528eb91138018bb82f8b48d040',273555541634492695,1234567890);
/*!40000 ALTER TABLE `clients_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `managers_table`
--

DROP TABLE IF EXISTS `managers_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `managers_table` (
  `_id` bigint(30) NOT NULL AUTO_INCREMENT,
  `lastName` varchar(20) NOT NULL,
  `firstName` varchar(20) NOT NULL,
  `emailAdrs` varchar(32) NOT NULL,
  `phoneNum` varchar(11) NOT NULL,
  `branchId` int(30) NOT NULL,
  `salt` bigint(40) NOT NULL,
  `password` varchar(64) NOT NULL,
  PRIMARY KEY (`_id`),
  UNIQUE KEY `emailAdrs` (`emailAdrs`),
  KEY `managers_table_ibfk_1` (`branchId`),
  CONSTRAINT `managers_table_ibfk_1` FOREIGN KEY (`branchId`) REFERENCES `branches_table` (`_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=305302938 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `managers_table`
--

LOCK TABLES `managers_table` WRITE;
/*!40000 ALTER TABLE `managers_table` DISABLE KEYS */;
INSERT INTO `managers_table` VALUES (0,'Manager','Big','n@gmail.com','05876543',2,-4380529157825030613,'6deeb6c94414a4ec49ea88beaebf1ae8749b1d74c00c94b8de8a4c9dc953d864'),(4646,'shshh','ghsg','nheifetz@g.jct.ac.il','7646',2,-6828818657316262352,'b2b8fe367782336f61e2fa237fdcc27b49dacf0efe71183e96c1286dde283a53'),(4949,'shsh','hj','n@n.c','7979',2,8739792590445903931,'4d6c47a4bd31ee6fe79e2bf71316b2b8138c58537fe348cb2c05e901b7ef9f55'),(8985,' vvg','ghh','v@h.h','08895',2,652219732390982418,'1cafa65f41ceae6d4d0a79b661fb6ba12d176bf03bd2f859469f91661ff15765'),(305302937,'Nagar','Yuval','yuval.nag.91@gmail.com','0524422258',2,-9149134158406827874,'904c9123a01054c78baf856227adf35e5d6d729ef19a57b0023b41117dcc3b7e');
/*!40000 ALTER TABLE `managers_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_table`
--

DROP TABLE IF EXISTS `orders_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders_table` (
  `_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_Status` tinyint(1) NOT NULL,
  `Client_Id` bigint(20) NOT NULL,
  `carNumber` int(20) NOT NULL,
  `rentDate` datetime NOT NULL,
  `returnDate` datetime DEFAULT NULL,
  `kilometersAtRent` bigint(20) NOT NULL,
  `kilometersAtReturn` int(11) NOT NULL DEFAULT '0',
  `fouled` tinyint(1) NOT NULL DEFAULT '0',
  `amountOfFoul` bigint(20) NOT NULL DEFAULT '0',
  `finalAmount` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`_id`),
  KEY `Client_Id` (`Client_Id`),
  KEY `carNumber` (`carNumber`),
  CONSTRAINT `orders_table_ibfk_1` FOREIGN KEY (`Client_Id`) REFERENCES `clients_table` (`_id`) ON UPDATE CASCADE,
  CONSTRAINT `orders_table_ibfk_2` FOREIGN KEY (`carNumber`) REFERENCES `cars_table` (`_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_table`
--

LOCK TABLES `orders_table` WRITE;
/*!40000 ALTER TABLE `orders_table` DISABLE KEYS */;
INSERT INTO `orders_table` VALUES (31,1,1,0,'2018-01-03 18:59:46','2018-01-03 18:59:56',0,100,0,0,100),(32,1,1,80,'2018-01-03 19:02:15','2018-01-03 19:02:21',4966,5832,0,0,100),(33,1,1,0,'2018-01-03 19:28:08','2018-01-03 19:28:16',100,150,0,0,100),(34,1,1,80,'2018-01-03 20:02:35','2018-01-03 20:02:46',5832,64797,0,0,100),(35,1,1,2223388,'2018-01-03 22:30:24','2018-01-04 14:37:32',122,380,0,0,100),(36,1,1,2426662,'2018-01-03 22:37:31','2018-01-04 14:32:20',580,658,0,0,100),(37,1,580580,0,'2018-01-03 23:01:13','2018-01-07 12:45:15',150,235,0,0,100),(38,1,1,586,'2018-01-04 00:11:49','2018-01-07 00:15:11',580,600,0,0,100),(39,1,1,80,'2018-01-04 00:12:11','2018-01-04 14:54:50',64797,64820,0,0,100),(40,1,1,80,'2018-01-05 00:10:27','2018-01-05 12:10:41',64820,64900,0,0,100),(41,1,1,1,'2018-01-05 08:54:38','2018-01-05 08:54:58',5900,5915,0,0,100),(42,1,1,458,'2018-01-07 00:02:47','2018-01-15 19:12:50',80,949,0,0,100),(43,1,580580,0,'2018-01-07 12:45:33','2018-01-07 12:45:42',235,300,0,0,100),(44,1,25896,0,'2018-01-07 15:35:40','2018-01-07 15:35:46',300,350,0,0,100),(45,1,308142488,25868,'2018-01-07 15:39:20','2018-01-07 15:39:48',58,579,0,0,100),(46,1,308142488,1,'2018-01-07 15:39:25','2018-01-07 19:50:17',5900,6000,0,0,100),(47,0,308142488,586,'2018-01-07 19:50:07',NULL,600,0,0,0,0),(48,1,1,566,'2018-01-08 17:16:50','2018-01-16 16:14:29',5665,5700,0,0,100),(49,1,1,80,'2018-01-08 17:17:04','2018-01-16 16:13:48',64900,64912,0,0,100),(50,1,1,123,'2018-01-15 16:00:59','2018-01-15 19:12:39',555,1424,0,0,100),(51,1,1,999,'2018-01-15 19:12:28','2018-01-15 19:12:45',88,957,0,0,100),(52,1,123,0,'2018-01-15 19:41:27','2018-01-15 20:03:02',3,564649,0,0,100),(53,1,123,2426662,'2018-01-15 19:50:59','2018-01-15 20:03:08',658899,1223545,0,0,100),(54,1,123,123,'2018-01-15 19:58:57','2018-01-15 20:04:28',1424,2290,0,0,100),(55,1,123,458,'2018-01-15 20:01:27','2018-01-15 20:35:24',949,2179,0,0,100),(56,0,123,2223388,'2018-01-15 20:01:33',NULL,380,0,0,0,0),(57,0,123,2426662,'2018-01-15 20:04:01',NULL,1223545,0,0,0,0),(58,0,123,1,'2018-01-15 20:04:07',NULL,6000,0,0,0,0),(59,0,123,0,'2018-01-15 20:04:56',NULL,564649,0,0,0,0),(60,0,123,123,'2018-01-15 20:33:26',NULL,2290,0,0,0,0),(61,0,123,558,'2018-01-15 20:34:50',NULL,888,0,0,0,0),(62,0,123,856,'2018-01-15 20:35:13',NULL,465656,0,0,0,0),(63,1,12345687,458,'2018-01-15 20:37:15','2018-01-15 20:37:30',2179,2180,0,0,100),(64,1,12345687,569,'2018-01-15 21:27:42','2018-01-15 21:27:58',58,4543522,0,0,100),(65,1,12345687,458,'2018-01-16 10:46:02','2018-01-16 10:46:13',2180,2200,0,0,100);
/*!40000 ALTER TABLE `orders_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-21 12:40:57

